To run this code:
open the link given in splicejunctionclassifier file in Google colab
install pandas
upload the dna.csv file given in folder in colab then change the path in pd.read_csv("..")  by copy pasting
then run all the cells
In the last cell you can see prediction scores
and In last second cell you can see output
